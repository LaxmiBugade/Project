import { Component, OnInit, Input } from '@angular/core';
import { Promo } from '../model/Promo';
import { PromoService } from '../service/promo.service';

@Component({
  selector: 'app-promo-create',
  templateUrl: './promo-create.component.html',
  styleUrls: ['./promo-create.component.css']
})
export class PromoCreateComponent {

  @Input() promoModel: Promo;
  
  constructor(private promoService: PromoService) { 
   this.promoModel = new Promo();
  }

  addPromo(){
    this.promoService.addPromo(this.promoModel).subscribe(
    result => {
      console.log(result)
      alert("Added Successfully")
    }, error => { console.log(error) }
  )
  this.promoModel = new Promo;
}

}
