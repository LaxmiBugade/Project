import { Component, OnInit } from '@angular/core';
import { Promo } from '../model/Promo';
import { PromoService } from '../service/promo.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  promoModel: Promo;
  constructor(private promoService: PromoService) { 
    this.promoModel = new Promo();
  }

  ngOnInit() {
    this.promoService.display(204).subscribe(
      result => {
        this.promoModel = result;
        console.log(this.promoModel);

        let endDate = new Date(this.promoModel.expiryDate).getTime();
        //console.log(endDate);
        let timer = setInterval(function() {
  
          /* Here comes the rest of JavaScript code. */
          let now = new Date().getTime(); 
          let t = endDate - now; 
  
          if (t >= 0) {
  
            this.promoModel.day = Math.floor(t / (1000 * 60 * 60 * 24));
            let hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let mins = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
            let secs = Math.floor((t % (1000 * 60)) / 1000);
            // console.log(days);console.log(hours);console.log(mins);console.log(secs);
            // this.promoModel.day = Number(days);
            this.promoModel.hours = hours;
            this.promoModel.mins = mins;
            this.promoModel.sec = secs;
          }
        }, 1000);

      }, error => { console.log(error) }
    )
  }

  applyPromo(){
    
  }
}//class end
