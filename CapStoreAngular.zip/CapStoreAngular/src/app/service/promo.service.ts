import { Injectable } from '@angular/core';
import { Promo } from '../model/Promo';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PromoService {

  promoArr: Promo[];
  baseHref: string;

  constructor(private http: HttpClient, private routes:Router) {
    this.promoArr = [];
    this.baseHref = "http://localhost:8880";
   }

  addPromo(promoModel: Promo) {
    var body = {
      promoTitle: promoModel.promoTitle,
      promoDescription: promoModel.promoDescription,
      //imagePath: promoModel.imagePath,
      productName: promoModel.productName,
      category: promoModel.category,
      discountAmount: promoModel.discountAmount,
      expiryDate: promoModel.expiryDate
    }
    return this.http.post<Promo>(this.baseHref + "/add", body);
   // this.routes.navigate(['/home']); 
  }

  display(id: number) {
    return this.http.get<Promo>(this.baseHref + "/home/" + id);
  }

}
