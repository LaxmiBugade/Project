import { InternalNgModuleRef } from '@angular/core/src/linker/ng_module_factory';

export class Promo{
    //variables declared
    public promoId: number;
    public promoTitle: String;
    public promoDescription: String;
    // public imagePath: String;
    public productName: String;
    public category: String;
    public discountAmount: number;
    public expiryDate: Date;
    public day: number;
    public hours: number;
    public min: number;
    public sec: number;
    

}